/*
 * Copyright (C) 2009 - 2018 Xilinx, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <stdio.h>
#include <string.h>

#include "xbram_hw.h" //Test
#include "xparameters.h" //Test
#include <stdlib.h> //Test

#include "lwip/err.h"
#include "lwip/tcp.h"
#if defined (__arm__) || defined (__aarch64__)
#include "xil_printf.h"
#endif

int transfer_data() {
	return 0;
}

void print_app_header()
{
#if (LWIP_IPV6==0)
	xil_printf("\n\r\n\r-----lwIP TCP echo server ------\n\r");
#else
	xil_printf("\n\r\n\r-----lwIPv6 TCP echo server ------\n\r");
#endif
	xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}

char* my_itoa(int i, char b[]){
    char const digit[] = "0123456789";
    char* p = b;
	if(i<0){
        *p++ = '-';
        i *= -1;
    }
    int shifter = i;
    do{ //Move to where representation ends
        ++p;
        shifter = shifter/10;
    }while(shifter);
    *p = '\0';
    do{ //Move back, inserting digits as u go
        *--p = digit[i%10];
        i = i/10;
    }while(i);
    return b;
}

err_t recv_callback(void *arg, struct tcp_pcb *tpcb,
                               struct pbuf *p, err_t err)
{
	int Data_in, Data_out, Data_out_Echo_1, Data_out_Echo_2, Data_out_Echo_3;
	static long long int address = 0x00B0000000;
	static int num = 0;
	char* pixel = "";
	char* string_payload;
	char* string_Data_out_Echo_1;
	char* string_Data_out_Echo_2;
	char* string_Data_out_Echo_3;
	char* concatted_out = "";
	int i = 0;
	int j = 0;
	int wait = 1;
	long long int BaseAddress_interface = 0x00A0008000;
	long long int BaseAddress_Grad = 0x00A0005000;
	long long int BaseAddress_Gamma = 0x00A0007000;
	long long int BaseAddress_Results = 0x00A0006000;
	long long int RegOffset_interface_reg0 = 0x0000000000;
	char buffer_1 [32];
	char buffer_2 [32];
	char buffer_3 [32];
	int debug_0, debug_1, debug_2, debug_3, debug_4, debug_5, debug_6, debug_7, debug_8;
	xil_printf("in recv_callback End = %d \n\r", XBram_ReadReg(BaseAddress_Results, RegOffset_interface_reg0));
	/* do not read the packet if we are not in ESTABLISHED state */
	if (!p) {
		tcp_close(tpcb);
		tcp_recv(tpcb, NULL);
		return ERR_OK;
	}

	/* indicate that the packet has been received */
	tcp_recved(tpcb, p->len);

	/* echo back the payload */
	/* in this case, we assume that the payload is < TCP_SND_BUF */
	if (tcp_sndbuf(tpcb) > p->len) {
		string_payload = p->payload;
		if(p->len == 10)
		{
			while (XBram_ReadReg(BaseAddress_Results, RegOffset_interface_reg0) == 0)
			{
				wait = 1;
			}
			Data_out_Echo_1 = XBram_In32(0x00B0008000); //bram_ctrl_2
			Data_out_Echo_2 = XBram_In32(0x00B0008004);
			Data_out_Echo_3 = XBram_In32(0x00B0008008);

			string_Data_out_Echo_1 = my_itoa(Data_out_Echo_1, buffer_1);
			string_Data_out_Echo_2 = my_itoa(Data_out_Echo_2, buffer_2);
			string_Data_out_Echo_3 = my_itoa(Data_out_Echo_3, buffer_3);

			/*xil_printf("Data_out_Echo_1 == %d \n\r", Data_out_Echo_1);
			xil_printf("string_Data_out_Echo_1 == %s \n\r", string_Data_out_Echo_1);
			xil_printf("length string_Data_out_Echo_1 == %d \n\r", strlen(string_Data_out_Echo_1));

			xil_printf("Data_out_Echo_2 == %d \n\r", Data_out_Echo_2);
			xil_printf("string_Data_out_Echo_2 == %s \n\r", string_Data_out_Echo_2);
			xil_printf("length string_Data_out_Echo_2 == %d \n\r", strlen(string_Data_out_Echo_2));

			xil_printf("Data_out_Echo_3 == %d \n\r", Data_out_Echo_3);
			xil_printf("string_Data_out_Echo_3 == %s \n\r", string_Data_out_Echo_3);
			xil_printf("length string_Data_out_Echo_3 == %d \n\r", strlen(string_Data_out_Echo_3));
*/
			strcpy(concatted_out, string_Data_out_Echo_1);
			strcat(concatted_out, ",");
			strcat(concatted_out, string_Data_out_Echo_2);
			strcat(concatted_out, ",");
			strcat(concatted_out, string_Data_out_Echo_3);

			/*xil_printf("concatted_out == %s \n\r", concatted_out);
			xil_printf("length concatted_out == %d \n\r", strlen(concatted_out));*/

			err = tcp_write(tpcb, concatted_out, strlen(concatted_out), 1);
		}
		else
		{
			err = tcp_write(tpcb, p->payload, p->len, 1);
		}

		while(i < p->len)
		{
			pixel[j] = string_payload[i];
			j++;
			i++;
			if(i % 10 == 0)
			{
				Data_in = atoi(pixel);
				XBram_Out32(address, Data_in);
				Data_out = XBram_In32(address);
				//xil_printf("address = %x \n\r", address);
				address = address + 4;
				j = 0;
				num++;
				if(address == 0x00B0007000) //bram_ctrl_1 + 3000 = 0x00B0007000  0x00B0006FCC
				{
					//xil_printf("Writing Images is DONE\n\r");
					XBram_WriteReg(BaseAddress_interface, RegOffset_interface_reg0, 1);
					XBram_WriteReg(BaseAddress_Grad, RegOffset_interface_reg0, 1);
					XBram_WriteReg(BaseAddress_Gamma, RegOffset_interface_reg0, 1);

					//xil_printf("num = %d \n\r", num);
					/*debug_0 = XBram_ReadReg(BaseAddress_interface, RegOffset_interface_reg0);
					debug_1 = XBram_ReadReg(BaseAddress_Grad, RegOffset_interface_reg0);
					debug_2 = XBram_ReadReg(BaseAddress_Gamma, RegOffset_interface_reg0);
					xil_printf("in debug_0 = %d \n\r", debug_0);
					xil_printf("in debug_1 = %d \n\r", debug_1);
					xil_printf("in debug_2 = %d \n\r", debug_2);

					debug_3 = XBram_ReadReg(0x00B0000000, 0x0000000000);
					debug_4 = XBram_ReadReg(0x00B0000004, 0x0000000000);
					debug_5 = XBram_ReadReg(0x00B0004000, 0x0000000000);
					xil_printf("in debug_3 = %d \n\r", debug_3);
					xil_printf("in debug_4 = %d \n\r", debug_4);
					xil_printf("in debug_5 = %d \n\r", debug_5);

					debug_6 = XBram_In32(0x00B0000000);
					debug_7 = XBram_In32(0x00B0000004);
					debug_8 = XBram_In32(0x00B0004000);
					xil_printf("in debug_6 = %d \n\r", debug_6);
					xil_printf("in debug_7 = %d \n\r", debug_7);
					xil_printf("in debug_8 = %d \n\r", debug_8);*/
				}
			}
		}
		if (p->len == 480)//60
		{
			address = 0x00B0004000; //bram_ctrl_1
			//xil_printf("address changed \n\r");
		}
	} else
		xil_printf("no space in tcp_sndbuf\n\r");

	/* free the received pbuf */
	pbuf_free(p);

	return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err)
{
	static int connection = 1;

	/* set the receive callback for this connection */
	tcp_recv(newpcb, recv_callback);

	/* just use an integer number indicating the connection id as the
	   callback argument */
	tcp_arg(newpcb, (void*)(UINTPTR)connection);

	/* increment for subsequent accepted connections */
	connection++;

	return ERR_OK;
}


int start_application()
{
	struct tcp_pcb *pcb;
	err_t err;
	unsigned port = 7;

	/* create new TCP PCB structure */
	pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);
	if (!pcb) {
		xil_printf("Error creating PCB. Out of Memory\n\r");
		return -1;
	}

	/* bind to specified @port */
	err = tcp_bind(pcb, IP_ANY_TYPE, port);
	if (err != ERR_OK) {
		xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
		return -2;
	}

	/* we do not need any arguments to callback functions */
	tcp_arg(pcb, NULL);

	/* listen for connections */
	pcb = tcp_listen(pcb);
	if (!pcb) {
		xil_printf("Out of memory while tcp_listen\n\r");
		return -3;
	}

	/* specify callback to use for incoming connections */
	tcp_accept(pcb, accept_callback);

	xil_printf("TCP echo server started @ port %d\n\r", port);

	return 0;
}
