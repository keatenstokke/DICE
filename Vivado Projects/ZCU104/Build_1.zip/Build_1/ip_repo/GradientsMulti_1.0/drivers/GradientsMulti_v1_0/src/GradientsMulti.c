

/***************************** Include Files *******************************/
#include "GradientsMulti.h"

/************************** Function Definitions ***************************/
